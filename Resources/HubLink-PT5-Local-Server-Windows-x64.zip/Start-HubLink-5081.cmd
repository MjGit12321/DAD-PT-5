@echo off
setlocal
if not exist "%~dp0HubLink-Service\HubLink.Api.exe" (
    echo HubLink.Api.exe was not found. Extract the entire ZIP first.
    pause
    exit /b 1
)
echo Starting HubLink on http://127.0.0.1:5081
echo Keep this window open. Press Ctrl+C or close it to stop the service.
echo Use port 5081 in the browser and in your application's base address.
echo.
pushd "%~dp0HubLink-Service"
"%~dp0HubLink-Service\HubLink.Api.exe" --urls http://127.0.0.1:5081
popd
echo.
echo HubLink has stopped. If it did not start, check the message above.
pause
